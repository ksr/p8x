/*/  Function name:   smsfsphere
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smsfsphere(rad, ang1, ang2, ang3)

    FIXPT  rad;
    FIXPT  ang1, ang2, ang3;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0243;

    LDFBUFF(ptrbuff, rad);
    LDFBUFF(ptrbuff, ang1);
    LDFBUFF(ptrbuff, ang2);
    LDFBUFF(ptrbuff, ang3);

    ioputbuf(buff, 9);
    }


