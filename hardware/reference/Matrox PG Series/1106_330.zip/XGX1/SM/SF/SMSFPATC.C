/*/  Function name:   smsfpatch
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:     ioputw:  send a word to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"


void smsfpatch(geomx, geomy, geomz)

    FIXPT  geomx[4][4];
    FIXPT  geomy[4][4];
    FIXPT  geomz[4][4];

    {
    ioputw(0x0268);

    ioputfbuf(geomx, 16);

    ioputfbuf(geomy, 16);
    
    ioputfbuf(geomz, 16);
    }


