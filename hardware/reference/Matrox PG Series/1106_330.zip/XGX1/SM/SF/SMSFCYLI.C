/*/  Function name:   smsfcylinder
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smsfcylinder(rad, len, angle)

    FIXPT  rad;
    FIXPT  len;
    FIXPT  angle;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0241;

    LDFBUFF(ptrbuff, rad);
    LDFBUFF(ptrbuff, len);
    LDFBUFF(ptrbuff, angle);

    ioputbuf(buff, 7);
    }


