/*/  Function name:   smsfcone
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smsfcone(radt, radb, len, ang)

    FIXPT  radt;
    FIXPT  radb;
    FIXPT  len;
    FIXPT  ang;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0242;

    LDFBUFF(ptrbuff, radt);
    LDFBUFF(ptrbuff, radb);
    LDFBUFF(ptrbuff, len);
    LDFBUFF(ptrbuff, ang);

    ioputbuf(buff, 9);
    }


