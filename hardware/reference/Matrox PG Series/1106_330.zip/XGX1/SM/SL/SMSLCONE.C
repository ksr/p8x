/*/  Function name:   smslcone
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslcone(radt, radb, len)

    FIXPT  radt;
    FIXPT  radb;
    FIXPT  len;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0202;

    LDFBUFF(ptrbuff, radt);
    LDFBUFF(ptrbuff, radb);
    LDFBUFF(ptrbuff, len);

    ioputbuf(buff, 7);
    }


