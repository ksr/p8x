/*/  Function name:   smsltube
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smsltube(radi, rade, len)

    FIXPT  radi;
    FIXPT  rade;
    FIXPT  len;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0207;

    LDFBUFF(ptrbuff, radi);
    LDFBUFF(ptrbuff, rade);
    LDFBUFF(ptrbuff, len);

    ioputbuf(buff, 7);
    }


