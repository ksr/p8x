/*/  Function name:   smslwedge
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslwedge(wid, ht, len)

    FIXPT  wid;
    FIXPT  ht;
    FIXPT  len;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0206;

    LDFBUFF(ptrbuff, wid);
    LDFBUFF(ptrbuff, ht);
    LDFBUFF(ptrbuff, len);

    ioputbuf(buff, 7);
    }


