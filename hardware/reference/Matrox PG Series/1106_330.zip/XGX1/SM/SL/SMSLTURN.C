/*/  Function name:   smslturned
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*               ioputf:  send a float to the board.
*
*    Uses:  V2COORD data structure.
*           FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslturned(nvert, vert, angle)

    unsigned short  nvert;
    V2COORD  *vert;
    FIXPT  angle;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0222;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);

    ioputfbuf(vert, 2 * nvert);

    ioputf(angle);
    }


