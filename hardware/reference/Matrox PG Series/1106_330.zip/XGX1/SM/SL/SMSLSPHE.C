/*/  Function name:   smslsphere
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslsphere(rad)

    FIXPT  rad;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0203;

    LDFBUFF(ptrbuff, rad);

    ioputbuf(buff, 3);
    }


