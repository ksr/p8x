/*/  Function name:   smsltorus
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smsltorus(radi, rade)

    FIXPT  radi;
    FIXPT  rade;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0204;

    LDFBUFF(ptrbuff, radi);
    LDFBUFF(ptrbuff, rade);

    ioputbuf(buff, 5);
    }


