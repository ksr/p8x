/*/  Function name:   smslextruded
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V2COORD data structure.
*           V3COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslextruded(nvert, vert, direction)

    unsigned short  nvert;
    V2COORD  *vert;
    V3COORD  *direction;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0221;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);

    ioputfbuf(vert, 2 * nvert);

    ioputfbuf(direction, 3);
    }


