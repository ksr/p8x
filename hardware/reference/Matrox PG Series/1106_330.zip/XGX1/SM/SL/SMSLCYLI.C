/*/  Function name:   smslcylinder
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smslcylinder(rad, len)

    FIXPT  rad;
    FIXPT  len;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0201;

    LDFBUFF(ptrbuff, rad);
    LDFBUFF(ptrbuff, len);

    ioputbuf(buff, 5);
    }


