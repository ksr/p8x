/*/  Function name:  smgpspatbas
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpspatbas(uid, vid)

    unsigned short  uid, vid;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02BA;
    *ptrbuff++ = uid;
    *ptrbuff = vid;

    ioputbuf(buff, 3);
    }


