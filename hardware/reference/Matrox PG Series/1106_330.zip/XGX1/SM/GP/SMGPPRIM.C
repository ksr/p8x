/*/  Function name:   smgpprimori
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpprimori(dx, dy, dz)

    FIXPT  dx, dy, dz;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02D2;

    LDFBUFF(ptrbuff, dx);
    LDFBUFF(ptrbuff, dy);
    LDFBUFF(ptrbuff, dz);

    ioputbuf(buff, 7);
    }


