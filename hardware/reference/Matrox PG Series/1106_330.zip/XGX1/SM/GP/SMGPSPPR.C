/*/  Function name:  smgpspatprec
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpspatprec(uprec, vprec)

    unsigned short  uprec, vprec;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02B9;
    *ptrbuff++ = uprec;
    *ptrbuff = vprec;

    ioputbuf(buff, 3);
    }


