/*/  Function name:  smgpspatcur
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpspatcur(ucurves, vcurves)

    unsigned short  ucurves, vcurves;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02BB;
    *ptrbuff++ = ucurves;
    *ptrbuff = vcurves;

    ioputbuf(buff, 3);
    }


