/*/  Function name:   smgpbasdef
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpbasdef(id, m)

    unsigned short  id;
    FIXPT  m[4][4];

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02B7;
    *ptrbuff = id;

    ioputbuf(buff, 2);

    ioputfbuf(m, 16);
    }


