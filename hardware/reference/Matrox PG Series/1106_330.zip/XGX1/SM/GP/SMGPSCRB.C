/*/  Function name:  smgpscurbas
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpscurbas(basis_id)

    unsigned short  basis_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02B2;
    *ptrbuff = basis_id;

    ioputbuf(buff, 2);
    }


