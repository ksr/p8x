/*/  Function name:  smgpscurprec
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpscurprec(prec)

    unsigned short  prec;
       
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02B1;
    *ptrbuff = prec;

    ioputbuf(buff, 2);
    }


