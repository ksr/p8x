/*/  Function name:  smgpstess
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void smgpstess(tindex)

    unsigned short  tindex;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C5;
    *ptrbuff = tindex;

    ioputbuf(buff, 2);
    }
