/*/  Function name:   smolcurve
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:     ioputw:  send a word to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"


void smolcurve(vert)

    V3COORD  vert[4];

    {
    ioputw(0x02A0);

    ioputfbuf(vert, 12);
    }


