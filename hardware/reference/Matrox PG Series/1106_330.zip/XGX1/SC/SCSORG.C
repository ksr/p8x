/*/  Function name:  scsorg
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scsorg(x, y)

    unsigned short  x, y;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0048;
    *ptrbuff++ = x;
    *ptrbuff = y;

    ioputbuf(buff, 3);
    }


