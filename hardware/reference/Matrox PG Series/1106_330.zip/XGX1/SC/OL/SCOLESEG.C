/*/  Function name:   scoleseg
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scoleseg(sth, eth, a, b, cx, cy)

    ANGLE  sth, eth;
    unsigned short  a, b;
    short  cx, cy;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0042;
    *ptrbuff++ = sth;
    *ptrbuff++ = eth;
    *ptrbuff++ = a;
    *ptrbuff++ = b;
    *ptrbuff++ = cx;
    *ptrbuff = cy;

    ioputbuf(buff, 7);
    }


