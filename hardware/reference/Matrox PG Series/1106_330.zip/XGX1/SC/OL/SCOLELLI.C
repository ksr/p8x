/*/  Function name:   scolellipse
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolellipse(a, b, cx, cy)

    unsigned short  a, b;
    short  cx, cy;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x003F;
    *ptrbuff++ = a;
    *ptrbuff++ = b;
    *ptrbuff++ = cx;
    *ptrbuff = cy;

    ioputbuf(buff, 5);
    }


