/*/  Function name:   scolsw
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolsw(new_width)

    short  new_width;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0039;
    *ptrbuff = new_width;

    ioputbuf(buff, 2);
    }


