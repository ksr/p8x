/*/  Function name:   scolseshp
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolseshp(begin_sh, middle_sh, end_sh)

    short  begin_sh;
    short  middle_sh;
    short  end_sh;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x003A;
    *ptrbuff++ = begin_sh;
    *ptrbuff++ = middle_sh;
    *ptrbuff = end_sh;

    ioputbuf(buff, 4);
    }


