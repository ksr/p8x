/*/  Function name:   scolhpearc
*
*    Author:   Jean Dupre
*    Date:     Feb 6, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolhpearc(sth, eth, a, b, cx, cy)

    FIXPT  sth, eth;
    unsigned short  a, b;
    short  cx, cy;

    {
    ptrbuff = buff;
    
    *ptrbuff++ = 0x0047;
    LDFBUFF(ptrbuff, sth);
    LDFBUFF(ptrbuff, eth);
    *ptrbuff++ = a;
    *ptrbuff++ = b;
    *ptrbuff++ = cx;
    *ptrbuff = cy;

    ioputbuf(buff, 9);
    }


