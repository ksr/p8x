/*/  Function name:   scolpline
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  PHCOORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolpline(nvert, vertptr)

    unsigned short  nvert;
    PHCOORD  *vertptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x003C;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);
    ioputbuf(vertptr, 2 * nvert);
    }


