/*/  Function name:   scolhspline
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scolhspline(x0, y0, x1, y1, x2, y2, x3, y3, nsteps)

    short  x0, y0;
    short  x1, y1;
    short  x2, y2;
    short  x3, y3;
    unsigned short  nsteps;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0043;
    *ptrbuff++ = x0;
    *ptrbuff++ = y0;
    *ptrbuff++ = x1;
    *ptrbuff++ = y1;
    *ptrbuff++ = x2;
    *ptrbuff++ = y2;
    *ptrbuff++ = x3;
    *ptrbuff++ = y3;
    *ptrbuff = nsteps;

    ioputbuf(buff, 10);
    }


