/*/  Function name:   sctxschrot
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxschrot(rot_angle)

    ANGLE  rot_angle;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006A;
    *ptrbuff = rot_angle;

    ioputbuf(buff, 2);
    }


