/*/  Function name:   sctxssow
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxssow(strike_out_thick)

    unsigned short  strike_out_thick;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006D;
    *ptrbuff = strike_out_thick;

    ioputbuf(buff, 2);
    }


