/*/  Function name:   sctxsalign
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsalign(halign, valign)

    short  halign;
    short  valign;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006B;
    *ptrbuff++ = halign;
    *ptrbuff = valign;

    ioputbuf(buff, 3);
    }


