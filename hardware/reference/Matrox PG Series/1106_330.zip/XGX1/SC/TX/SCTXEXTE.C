/*/  Function name:   sctxextent
*
*    Note:  Use the C binding's "iogetbuf" function to retrieve the data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxextent(x, y, strptr)

    short  x, y;
    short  *strptr;

    {
    unsigned short  length = 0;
    short  *ptrtxt;

    ptrtxt = strptr;

    while (*ptrtxt++)
        length++;

    ptrbuff = buff;

    *ptrbuff++ = 0x0074;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = length;

    ioputbuf(buff, 4);
    ioputbuf(strptr, length);
    }


