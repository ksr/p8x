/*/  Function name:   sctxsdmode
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsdmode(mode)

    short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0079;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


