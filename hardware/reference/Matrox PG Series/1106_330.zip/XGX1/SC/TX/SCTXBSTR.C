/*/  Function name:   sctxbstring
*
*    Note:  Values returned in the read fifo depend on the selected string
*           drawing mode.
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*            ioputtxt:  send a text string to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxbstring(x, y, strptr)

    short  x, y;
    char  *strptr;

    {
    unsigned short  length = strlen(strptr);

    ptrbuff = buff;

    *ptrbuff++ = 0x0072;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = length;

    ioputbuf(buff, 4);
    ioputtxt(strptr, length);
    }


