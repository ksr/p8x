/*/  Function name:   sctxswpw
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxswpw(width)

    short  width;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0071;
    *ptrbuff = width;

    ioputbuf(buff, 2);
    }


