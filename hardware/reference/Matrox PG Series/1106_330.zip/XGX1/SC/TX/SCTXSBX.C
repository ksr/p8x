/*/  Function name:   sctxsbx
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsbx(extra_space)

    FIXPT  extra_space;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0075;
    LDFBUFF(ptrbuff, extra_space);

    ioputbuf(buff, 3);
    }


