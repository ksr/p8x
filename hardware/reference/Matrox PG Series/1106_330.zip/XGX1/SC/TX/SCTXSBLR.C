/*/  Function name:   sctxsblrot
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsblrot(baseline_angle)

    ANGLE  baseline_angle;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0069;
    *ptrbuff = baseline_angle;

    ioputbuf(buff, 2);
    }


