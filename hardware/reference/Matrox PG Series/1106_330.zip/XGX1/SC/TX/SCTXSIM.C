/*/  Function name:   sctxsim
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsim(ital_mask)

    unsigned short  ital_mask;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006E;
    *ptrbuff = ital_mask;

    ioputbuf(buff, 2);
    }


