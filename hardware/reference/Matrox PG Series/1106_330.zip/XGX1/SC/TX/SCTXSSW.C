/*/  Function name:  sctxssw
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*                                     
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxssw(stroke_width)

    unsigned short  stroke_width;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0077;
    *ptrbuff = stroke_width;

    ioputbuf(buff, 2);
    }
