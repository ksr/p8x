/*/  Function name:   sctxsuw
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsuw(underline_thick)

    short  underline_thick;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006C;
    *ptrbuff = underline_thick;

    ioputbuf(buff, 2);
    }


