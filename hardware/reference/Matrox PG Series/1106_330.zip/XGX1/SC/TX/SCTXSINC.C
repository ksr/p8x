/*/  Function name:   sctxsincs
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsincs(inter_char)

    short  inter_char;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0073;
    *ptrbuff = inter_char;

    ioputbuf(buff, 2);
    }


