/*/  Function name:   sctxsbf
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxsbf(bolding_factor)

    short  bolding_factor;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0070;
    *ptrbuff = bolding_factor;

    ioputbuf(buff, 2);
    }


