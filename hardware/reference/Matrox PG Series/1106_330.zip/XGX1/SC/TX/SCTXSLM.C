/*/  Function name:   sctxslm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxslm(lightmask)

    unsigned short  lightmask;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x006F;
    *ptrbuff = lightmask;

    ioputbuf(buff, 2);
    }


