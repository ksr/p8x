/*/  Function name:   sctxssf
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxssf(xscale, yscale)

    FIXPT  xscale, yscale;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0068;
    LDFBUFF(ptrbuff, xscale);
    LDFBUFF(ptrbuff, yscale);

    ioputbuf(buff, 5);
    }


