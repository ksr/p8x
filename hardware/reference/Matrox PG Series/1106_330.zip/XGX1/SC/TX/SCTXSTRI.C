/*/  Function name:   sctxstring
*
*    Note:  Values returned in the read fifo depend on the selected string
*           drawing mode.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void sctxstring(x, y, strptr)

    short  x, y;
    short  *strptr;

    {
    unsigned short  length = 0;
    short  *ptrtxt;

    ptrtxt = strptr;

    while (*ptrtxt++)
        length++;

    ptrbuff = buff;

    *ptrbuff++ = 0x0072;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = length;

    ioputbuf(buff, 4);
    ioputbuf(strptr, length);
    }


