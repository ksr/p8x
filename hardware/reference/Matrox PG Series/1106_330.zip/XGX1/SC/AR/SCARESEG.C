/*/  Function name:   scareseg
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scareseg(sth, eth, a, b, cx, cy)

    ANGLE  sth, eth;
    unsigned short  a, b;
    short  cx, cy;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0055;
    *ptrbuff++ = sth;
    *ptrbuff++ = eth;
    *ptrbuff++ = a;
    *ptrbuff++ = b;
    *ptrbuff++ = cx;
    *ptrbuff = cy;

    ioputbuf(buff, 7);
    }


