/*/  Function name:   scarspin
*
*    Author:   Francois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarspin(pin_flag)

    short  pin_flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x005C;
    *ptrbuff = pin_flag;

    ioputbuf(buff, 2);
    }


