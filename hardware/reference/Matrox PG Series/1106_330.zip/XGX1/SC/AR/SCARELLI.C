/*/  Function name:   scarellipse
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarellipse(a, b, cx, cy)

    unsigned short  a, b;
    short  cx, cy;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0053;
    *ptrbuff++ = a;
    *ptrbuff++ = b;
    *ptrbuff++ = cx;
    *ptrbuff = cy;

    ioputbuf(buff, 5);
    }


