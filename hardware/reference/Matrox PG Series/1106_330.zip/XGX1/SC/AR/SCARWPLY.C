/*/  Function name:   scarwplygn
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  PHCOORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarwplygn(nvert, vertptr)

    unsigned short  nvert;
    PHCOORD  *vertptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0052;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);
    ioputbuf(vertptr, 2 * nvert);
    }


