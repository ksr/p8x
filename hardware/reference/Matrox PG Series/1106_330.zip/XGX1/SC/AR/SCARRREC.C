/*/  Function name:   scarrrect
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarrrect(x0, y0, x1, y1, a, b)

    short  x0, y0;
    short  x1, y1;
    unsigned short  a, b;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0050;
    *ptrbuff++ = x0;
    *ptrbuff++ = y0;
    *ptrbuff++ = x1;
    *ptrbuff++ = y1;
    *ptrbuff++ = a;
    *ptrbuff = b;

    ioputbuf(buff, 7);
    }


