/*/  Function name:   scarrect
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarrect(x0, y0, x1, y1)

    short  x0, y0;
    short  x1, y1;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x004F;
    *ptrbuff++ = x0;
    *ptrbuff++ = y0;
    *ptrbuff++ = x1;
    *ptrbuff = y1;

    ioputbuf(buff, 5);
    }


