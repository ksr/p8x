/*/  Function name:   scaraplygn
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  PHCOORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scaraplygn(nvert, vertptr)

    unsigned short  nvert;
    PHCOORD  *vertptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0051;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);
    ioputbuf(vertptr, 2 * nvert);
    }


