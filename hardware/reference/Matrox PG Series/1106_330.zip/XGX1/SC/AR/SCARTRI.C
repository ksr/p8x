/*/  Function name:   scartri
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scartri(x1, y1, x2, y2, x3, y3)

    short  x1, y1, x2, y2, x3, y3;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x005B;
    *ptrbuff++ = x1;
    *ptrbuff++ = y1;
    *ptrbuff++ = x2;
    *ptrbuff++ = y2;
    *ptrbuff++ = x3;
    *ptrbuff = y3;

    ioputbuf(buff, 7);
    }


