/*/  Function name:   scarbfill
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void scarbfill(x, y, color_index)

    short  x, y;
    unsigned short  color_index;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0057;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = color_index;

    ioputbuf(buff, 4);
    }


