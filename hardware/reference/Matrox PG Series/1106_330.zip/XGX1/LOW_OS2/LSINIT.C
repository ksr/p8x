/*/  Function name:  lsinit
*
*    synopsis: initializes the binding to communicate with a FILE device,
*	       either the PG/SM-1281 or a regular file.
*
*    Author:   Robert Keller
*    Date:     Apr 14, 1988
*
*    Uses:  Global variables "pgcfile" and "ioseg".
*
*    Return value:  None
*/

#include  "def.h"
#include  "iolib.h"


#define   CBUFFLENGTH	1024


/* Buffer reserved for transfers between the PG-1281 C binding library */
/* and the board.						       */

short  buff[CBUFFLENGTH];


/* Pointer to shorts (16 bits signed integer) */

short  *ptrbuff;


/* The file that output is written to */

short  pgcfile = 0;

/* Whether pgcfile points to a file or the PG/SM-1281 */

short  device = 0;		/* TRUE for PG/SM-1281, FALSE otherwise */


void lsinit(fhandle, flag)

    short  fhandle;
    short  flag;

    {

    if (fhandle == 0)
	{
	pgcfile = 0;
	printf("lsinit:  Null FILE handle\n");
	exit(-1);
	}

    pgcfile = fhandle;
    device = flag;
    }



