/*/  Function name:  ioflush
*
*    Synopsis:	Emptys the fifos.
*
*    Author:   Frank
*    Date:     Apr 15, 1988
*
*    Modification history:
*
*    Calls:  Lib Shell "rdfifocnt" command.
*	     Lib Shell "rdfifocnt" command.
*	     Lib Shell "iogetw" command.
*
*/
void ioflush()

    {
    while (wrfifocnt() != 0);
    while (rdfifocnt() != 0) iogetw();
    }

