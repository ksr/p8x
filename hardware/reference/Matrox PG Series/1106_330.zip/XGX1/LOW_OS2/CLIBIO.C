/*/   clibio.c
*
*     Standard PG-1281 C binding low-level routines.
*
*     COPYRIGHT (C) 1987  Matrox Electronic Systems Ltd.
*                         All rights reserved
*
*
*       [name]            [functional description]
*  -------------------------------------------------------------------------
*
*      ioputw()         send a word to the board.
*      ioputf()         send a float to the board.
*      ioputbuf()       send a buffer of words to the board.
*      ioputfbuf()      send a buffer of floats to the board.
*      ioputtxt()       send a text string to the board.
*      iogetw()         get a word from the board.
*      iogetf()         get a float from the board.
*      iogetbuf()       get a buffer of words from the board.
*      wrfifocnt()      get the write fifo count.
*      rdfifocnt()      get the read fifo count.
*      lslibsync()      synchronize command process.
*      ioflush()        flush read and write fifos.
*      lscold()         cold resets the PG-1281.
*      lswarm()         warm resets the PG-1281.
*/

#include  "def.h"
#include  "iolib.h"
#include  "lib.h"
#include <doscalls.h>


/* Reference to output file handle */

IMPORT  short  pgcfile;

/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;

/* structure to communicate to the PG/SM-1281 driver IOCTL calls */

struct lsstruct lscom;
short  lsnum;


void ioputw(val)                  /* put word onto command buffer */

    short  val;

    {
   if (  DOSDEVIOCTL((char far *)&val,
                     (char far *)0L,
                     (unsigned) LS_WRITE_WRD,
                     (unsigned) 0x80,
                     (unsigned) pgcfile) == -1)
       {
       printf("ioputw:  error reading driver file\n");
       exit(-1);
       }
    }


void ioputf(val)                  /* put 16.16 float onto command buffer */

    float  val;

    {
    short  p1, p2;

    p1 = (unsigned short)(val * 65536.0);
    p2 = ((unsigned short)(val * 65536.0))>> 16;

    if (  DOSDEVIOCTL((char far *)&p2,
                      (char far *)0L,
                      (unsigned) LS_WRITE_WRD,
                      (unsigned) 0x80,
                      (unsigned) pgcfile) == -1)
        {
        printf("ioputf:  error reading driver file\n");
        exit(-1);
        }
    if (  DOSDEVIOCTL((char far *)&p1,
                      (char far *)0L,
                      (unsigned) LS_WRITE_WRD,
                      (unsigned) 0x80,
                      (unsigned) pgcfile) == -1)
        {
        printf("ioputf:  error reading driver file\n");
        exit(-1);
        }
    }


void ioputbuf(buf, nwords)        /* put nwords onto command buffer */

    short  *buf, nwords;

    {
    if (  DOSDEVIOCTL((char far *)buf,
                      (char far *)&nwords,
                      (unsigned) LS_WRITE_BUF,
                      (unsigned) 0x80,
                      (unsigned) pgcfile) == -1)
        {
        printf("ioputbuf:  error reading driver file\n");
        exit(-1);
        }

    }


void ioputfbuf(buf, nfloats)      /* put nfloats onto the command buffer */

    float  *buf;
    short  nfloats;

    {
    short  p1, p2;

    while (nfloats-- > 0)
       {
       p1 = (unsigned short)(*buf * 65536.0);
       p2 = ((unsigned short)(*buf++ * 65536.0)) >> 16;
        if (  DOSDEVIOCTL((char far *)&p2,
                          (char far *)0L,
                          (unsigned) LS_WRITE_WRD,
                          (unsigned) 0x80,
                          (unsigned) pgcfile) == -1)
            {
            printf("ioputf:  error reading driver file\n");
            exit(-1);
            }
        if (  DOSDEVIOCTL((char far *)&p1,
                          (char far *)0L,
                          (unsigned) LS_WRITE_WRD,
                          (unsigned) 0x80,
                          (unsigned) pgcfile) == -1)
            {
            printf("ioputf:  error reading driver file\n");
            exit(-1);
            }
        }
    }


void ioputtxt(string, nchars)     /* send a text string to the board */

    char  *string;
    short  nchars;

    {
    if (  DOSDEVIOCTL((char far *)string,
                      (char far *)&nchars,
                      (unsigned) LS_WRITE_TXT,
                      (unsigned) 0x80,
                      (unsigned) pgcfile) == -1)
        {
        printf("ioputtxt:  error reading driver file\n");
        exit(-1);
        }
    }


short iogetw()                    /* get word from report buffer */

    {
    short  val;

    if (device)
        {
        if (read(pgcfile, &val, 2) == -1)
            {
            printf("iogetw:  error reading driver file\n");
            exit(-1);
            }
        }
    else
        {
        printf("iogetw:  readback invalid from a file\n");
        exit(-1);
        }

    return(val);
    }


float iogetf()                    /* get 16.16 float from report buffer */

    {
    long            val;

    val = ((unsigned long) iogetw());
    val += ((unsigned long) iogetw() << 16);

    return((float) val / 65536.0);
    }


void iogetbuf(buf, nwords)        /* get nwords from report buffer */

    short  *buf, nwords;

    {

    if (device)
        {
        if (read(pgcfile, buf, 2 * nwords) == -1)
            {
            printf("iogetbuf:  error reading driver file\n");
            exit(-1);
            }
        }
    else
        {
        printf("iogetbuf:  readback invalid from a file\n");
        exit(-1);
        }
    }

short wrfifocnt()                 /* get the write fifo count */

    {

    if (device)
        {

        if (  DOSDEVIOCTL((char far *)&lscom,
                          (char far *)0L,
                          (unsigned) WRFIFOCNT,
                          (unsigned) 0x80,
                          (unsigned) pgcfile) == -1)
            {
            printf("wrfifocnt:  error reading driver file\n");
            exit(-1);
            }
        }
    else
        {
        printf("wrfifocnt:  readback invalid from a file\n");
        exit(-1);
        }

    return(lscom.lsshort);
    }


short rdfifocnt()                 /* get the read fifo count */

    {
    if (device)
        {
        if (  DOSDEVIOCTL((char far *)&lscom,
                          (char far *)0L,
                          (unsigned) RDFIFOCNT,
                          (unsigned) 0x80,
                          (unsigned) pgcfile) == -1)
            {
            printf("rdfifocnt:  error reading driver file\n");
            exit(-1);
            }
        }
    else
        {
        printf("rdfifocnt:  readback invalid from a file\n");
        exit(-1);
        }

    return(lscom.lsshort);
    }


void lscold()

    {

    if (device)
       {
       DOSDEVIOCTL((char far *)&lscom,
                   (char far *)0L,
                   (unsigned) LS_COLD,
                   (unsigned) 0x80,
                   (unsigned) pgcfile);
       }
    }


void lswarm()

    {

    if (device)
       {
       DOSDEVIOCTL((char far *)&lscom,
                   (char far *)0L,
                   (unsigned) LS_WARM,
                   (unsigned) 0x80,
                   (unsigned) pgcfile);
       }
    }
