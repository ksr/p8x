/*/  Function name:  lslibsync
*
*    Synopsis:	Synchronize board with program.
*
*    Author:   Frank
*    Date:     Apr 15, 1988
*
*    Modification history:
*
*    Calls:  Lib Shell "lsnoop" command.
*	     Lib Shell "wrfifocnt" command.
*/
void lslibsync()

    {
    lsnoop();
    while (wrfifocnt() != 0);
    }

