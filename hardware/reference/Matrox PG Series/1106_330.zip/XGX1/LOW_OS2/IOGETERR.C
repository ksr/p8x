/*/  Function name:  iogeterror
*
*    Synopsis:	Get a word from the error report register.
*
*    Author:   Jean Dupre
*    Date:     Dec 15, 1987
*
*    Modification history:
*
*    Calls:  Lib Shell "lslibsync" command.
*
*    Uses:  Global variable "ioseg".
*
*    Return value:  word (16 bits)
*/


#include  "def.h"
#include  "iolib.h"
#include  "lib.h"
#include <doscalls.h>

/* Reference to output file handle */

IMPORT	short  pgcfile;

/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT	short  device;

/* structure to communicate to the PG/SM-1281 driver IOCTL calls */

struct lsstruct lscom;


short iogeterror()

    {
    if (device) 			/* Make sure that previous commands */
	{				/* are completed */
	if (  DOSDEVIOCTL((char far *)&lscom,
			  (char far *)0L,
			  (unsigned) LS_SYNC,
			  (unsigned) 0x80,
			  (unsigned) pgcfile) == -1)
	    {
	    printf("lslibgeterror:  error reading driver file\n");
	    exit(-1);
	    }

	if (  DOSDEVIOCTL((char far *)&lscom,
			  (char far *)0L,
			  (unsigned) LS_GETERR,
			  (unsigned) 0x80,
			  (unsigned) pgcfile) == -1)
	    {
	    printf("lslibgeterror:  error reading driver file\n");
	    exit(-1);
	    }
	}
    return(lscom.lsshort);
    }


