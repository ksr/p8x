/*/  Function name:  kriossmode
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void kriossmode(swapmode)

    short  swapmode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0012;
    *ptrbuff = swapmode;

    ioputbuf(buff, 2);
    }


