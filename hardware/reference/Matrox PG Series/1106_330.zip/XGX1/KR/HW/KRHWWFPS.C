/*/  Function name:  krhwwfps
*
*    Note:  Use the C binding's "iogetw" function to retrieve data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwwfps(sy, xstart, xend)

    short  sy;
    short  xstart, xend;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x002A;
    *ptrbuff++ = sy;
    *ptrbuff++ = xstart;
    *ptrbuff = xend;

    ioputbuf(buff, 4);
    }


