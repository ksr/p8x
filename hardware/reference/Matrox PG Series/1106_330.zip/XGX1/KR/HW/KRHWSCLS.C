/*/  Function name:  krhwscls
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwscls(line_style)

    unsigned long  line_style;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0015;
    *ptrbuff++ = (unsigned short)line_style;            /* low word  */
    *ptrbuff = (unsigned short)(line_style >> 16);      /* high word */

    ioputbuf(buff, 3);
    }


