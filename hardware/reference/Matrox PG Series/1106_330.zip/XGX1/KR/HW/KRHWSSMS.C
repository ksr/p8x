/*/  Function name:  krhwssmsk
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwssmsk(mask)

    unsigned short  mask;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x001D;
    *ptrbuff = mask;

    ioputbuf(buff, 2);
    }


