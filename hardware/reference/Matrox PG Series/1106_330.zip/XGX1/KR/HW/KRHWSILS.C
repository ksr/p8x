/*/  Function name:  krhwsils
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsils(new_style)

    unsigned long  new_style;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0038;
    *ptrbuff++ = (unsigned short)new_style;             /* low word  */
    *ptrbuff = (unsigned short)(new_style >> 16);       /* high word */

    ioputbuf(buff, 3);
    }


