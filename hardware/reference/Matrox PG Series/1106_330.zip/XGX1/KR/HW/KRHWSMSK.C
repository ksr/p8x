/*/  Function name:  krhwsmsk
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsmsk(mask)

    unsigned short  mask;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x001C;
    *ptrbuff = mask;

    ioputbuf(buff, 2);
    }


