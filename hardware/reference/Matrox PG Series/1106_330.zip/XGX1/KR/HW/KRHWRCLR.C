/*/  Function name:   krhwrclr
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwrclr(left, top, right, bottom, color_index)

    short  left, top, right, bottom;
    unsigned short  color_index;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0024;
    *ptrbuff++ = left;
    *ptrbuff++ = top;
    *ptrbuff++ = right;
    *ptrbuff++ = bottom;
    *ptrbuff = color_index;

    ioputbuf(buff, 6);
    }


