/*/  Function name:  krhwsclr
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsclr(color_index)

    unsigned short  color_index;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0022;
    *ptrbuff = color_index;

    ioputbuf(buff, 2);
    }
