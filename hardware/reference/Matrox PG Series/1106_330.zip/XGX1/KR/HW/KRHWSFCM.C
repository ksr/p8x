/*/  Function name:  krhwsfcm
*
*    Author:   Andre Allore
*    Date:     February 17, 1989
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsfcm(mode)

    unsigned short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0010;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


