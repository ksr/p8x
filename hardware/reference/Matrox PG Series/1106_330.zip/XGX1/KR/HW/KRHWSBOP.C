/*/  Function name:   krhwsbop
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsbop(bool_operator)

    short  bool_operator;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x001B;
    *ptrbuff = bool_operator;

    ioputbuf(buff, 2);
    }


