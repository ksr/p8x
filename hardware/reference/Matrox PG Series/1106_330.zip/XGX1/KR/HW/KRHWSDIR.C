/*/  Function name:  krhwsdirect
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsdirect(mode)

    short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0017;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


