/*/  Function name:  krhwcpxmss
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwcpxmss(spx, spy, dpx, dpy, sizex, sizey)

    short  spx, spy;
    short  dpx, dpy;
    short  sizex, sizey;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0030;
    *ptrbuff++ = spx;
    *ptrbuff++ = spy;
    *ptrbuff++ = dpx;
    *ptrbuff++ = dpy;
    *ptrbuff++ = sizex;
    *ptrbuff = sizey;

    ioputbuf(buff, 7);
    }


