/*/  Function name:  krhwcprss
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwcprss(spx, spy, dpx, dpy, sizex, sizey, theta)

    short  spx, spy;
    short  dpx, dpy;
    short  sizex, sizey;
    ANGLE  theta;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x002F;
    *ptrbuff++ = spx;
    *ptrbuff++ = spy;
    *ptrbuff++ = dpx;
    *ptrbuff++ = dpy;
    *ptrbuff++ = sizex;
    *ptrbuff++ = sizey;
    *ptrbuff = theta;

    ioputbuf(buff, 8);
    }


