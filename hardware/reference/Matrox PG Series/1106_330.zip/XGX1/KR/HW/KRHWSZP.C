/*/  Function name:  krhwszp
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwszp(zoomx, zoomy, panx, pany, finepanx, finepany)

    short  zoomx, zoomy;
    short  panx, pany;
    short  finepanx, finepany;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0011;
    *ptrbuff++ = zoomx;
    *ptrbuff++ = zoomy;
    *ptrbuff++ = panx;
    *ptrbuff++ = pany;
    *ptrbuff++ = finepanx;
    *ptrbuff = finepany;

    ioputbuf(buff, 7);
    }


