/*/  Function name:  krhwgpix
*
*    Note:  Use the C binding's "iogetw" function to retrieve data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwgpix(x, y)

    short  x, y;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0028;
    *ptrbuff++ = x;
    *ptrbuff = y;

    ioputbuf(buff, 3);
    }


