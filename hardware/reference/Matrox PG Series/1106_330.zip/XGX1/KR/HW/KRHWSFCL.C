/*/  Function name:  krhwsfclr
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krhwsfclr(color)

    unsigned short  color;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02FA;
    *ptrbuff = color;

    ioputbuf(buff, 2);
    }
