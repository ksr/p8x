/*/  Function name:  krhwrcls
*
*    Author:   Jean Dupre
*    Date:     Sept 28, 1987
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"


void krhwrcls()

    {
    ioputw(0x0016);
    }


