/*/  Function name:  krgcsda
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:    ioputw:  send a word to the board.
*            ioputbuf:  send a buffer of words to the board.
*
*    Uses:  GCATTR data structure.
*
*    Return value:  None
*/

#include  "def.h"


void krgcsda(gcspecptr)

    GCATTR  *gcspecptr;

    {
    ioputw(0x0082);

    ioputbuf(gcspecptr, 11);
    }


