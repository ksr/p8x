/*/  Function name:  krgcfr
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void krgcfr()

    {
    ioputw(0x007E);
    }
