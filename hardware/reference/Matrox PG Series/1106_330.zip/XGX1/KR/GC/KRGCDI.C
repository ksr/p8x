/*/  Function name:  krgcdi
*
*    Note:  For compatibility with previous version, the old function name
*           "lsgcdi" can also be used.
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void krgcdi()

    {
    ioputw(0x0084);
    }


void lsgcdi()

    {
    ioputw(0x0084);
    }

