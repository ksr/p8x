/*/  Function name:  krgcmv
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krgcmv(x, y)

    short  x, y;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0085;
    *ptrbuff++ = x;
    *ptrbuff = y;

    ioputbuf(buff, 3);
    }


