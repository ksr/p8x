/*/  Function name:  krgcsdm
*
*    Note:  For compatibility with previous version, the old function name
*           "lsgcsdm" can also be used.
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krgcsdm(disp_mode)

    short  disp_mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0086;
    *ptrbuff = disp_mode;

    ioputbuf(buff, 2);
    }


void lsgcsdm(disp_mode)

    short  disp_mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0086;
    *ptrbuff = disp_mode;

    ioputbuf(buff, 2);
    }

