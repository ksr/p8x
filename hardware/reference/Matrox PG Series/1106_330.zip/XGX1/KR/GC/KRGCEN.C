/*/  Function name:  krgcen
*
*    Note:  For compatibility with previous version, the old function name
*           "lsgcen" can also be used.
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void krgcen()

    {
    ioputw(0x0083);
    }


void lsgcen()

    {
    ioputw(0x0083);
    }

