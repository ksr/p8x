/*/  Function name:  krmdsdcue
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krmdsdcue(flag)

    BOOL  flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C8;
    *ptrbuff = flag;

    ioputbuf(buff, 2);
    }


