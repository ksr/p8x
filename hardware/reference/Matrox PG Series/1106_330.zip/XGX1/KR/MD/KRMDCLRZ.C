/*/  Function name:  krmdclrz
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krmdclrz(color)

    unsigned short  color;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02D8;
    *ptrbuff = color;

    ioputbuf(buff, 2);
    }
