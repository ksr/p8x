/*/  Function name:  krmdsdcuepl
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krmdsdcuepl(fplane, bplane)

    unsigned short  fplane, bplane;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02CA;
    *ptrbuff++ = fplane;
    *ptrbuff = bplane;

    ioputbuf(buff, 3);
    }


