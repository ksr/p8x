/*/  Function name:  krmdstran
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krmdstran(tlevel)

    unsigned short  tlevel;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C4;
    *ptrbuff = tlevel;

    ioputbuf(buff, 2);
    }
