/*/  Function name:   krmdsdcuesc
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void krmdsdcuesc(fscale, bscale)

    FIXPT  fscale, bscale;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C9;

    LDFBUFF(ptrbuff, fscale);
    LDFBUFF(ptrbuff, bscale);
    
    ioputbuf(buff, 5);
    }


