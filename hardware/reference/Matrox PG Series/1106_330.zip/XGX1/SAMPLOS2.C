/*/  samplos2.c
*
*    Sample program for the PG-1281 C binding library under OS/2
*/

#include "fcntl.h"
#include <doscalls.h>

void main()

    {
    short lsfh,err;
    long  filesize;

    DOSOPEN((char far *) "$LIB",
	    (unsigned far *) &lsfh,
	    (unsigned far *) &err,
	    (unsigned long) filesize,
	    (unsigned) 0x0,
	    (unsigned) 0x01,
	    (unsigned) 0x0042,
	    (unsigned long) 0);

    lsinit(lsfh, 1);

    krhwsclr(24);

    scolsw(15);
    krhwsfcol(0);
    krhwstdef(1);

    lssfont(-1);
    sctxssf(2.0, 3.0);

    scolrrect(310, 350, 940, 650, 20, 20);
    sctxbstring(405, 450, "Matrox PG-1281");

    close(lsfh);
    }

