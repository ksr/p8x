/*/  Function name:   v316lnto
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v316lnto(x, y, z)

    short  x, y, z;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02A3;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = z;

    ioputbuf(buff, 4);
    }


