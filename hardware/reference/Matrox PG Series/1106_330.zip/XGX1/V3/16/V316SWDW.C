/*/  Function name:  v316swdw
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v316swdw(wleft, wright, wbot, wtop)

    short  wleft;
    short  wright;
    short  wbot;
    short  wtop;
       
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02A5;
    *ptrbuff++ = wleft;
    *ptrbuff++ = wright;
    *ptrbuff++ = wbot;
    *ptrbuff = wtop;

    ioputbuf(buff, 5);
    }


