/*/  Function name:   v316mvto
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v316mvto(x, y, z)

    short  x, y, z;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02A2;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff = z;

    ioputbuf(buff, 4);
    }


