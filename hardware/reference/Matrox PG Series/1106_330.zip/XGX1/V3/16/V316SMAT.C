/*/  Function name:  v316smat
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v316smat(xx, xy, yx, yy, zx, zy, xo, yo)

    short  xx, xy;
    short  yx, yy;
    short  zx, zy;
    short  xo, yo;
       
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0294;
    *ptrbuff++ = xx;
    *ptrbuff++ = xy;
    *ptrbuff++ = yx;
    *ptrbuff++ = yy;
    *ptrbuff++ = zx;
    *ptrbuff++ = zy;
    *ptrbuff++ = xo;
    *ptrbuff = yo;

    ioputbuf(buff, 9);
    }


