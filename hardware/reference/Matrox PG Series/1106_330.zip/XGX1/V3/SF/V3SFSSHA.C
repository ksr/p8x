/*/  Function name:  v3sfsshad
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfsshad(shtype)

    unsigned short  shtype;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C1;
    *ptrbuff = shtype;

    ioputbuf(buff, 2);
    }
