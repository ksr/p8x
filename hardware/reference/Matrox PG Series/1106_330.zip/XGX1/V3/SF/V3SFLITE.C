/*/  Function name:  v3sfliten
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfliten(light_id, flag)

    unsigned short  light_id;
    BOOL  flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02D1;
    *ptrbuff++ = light_id;
    *ptrbuff = flag;

    ioputbuf(buff, 3);
    }


