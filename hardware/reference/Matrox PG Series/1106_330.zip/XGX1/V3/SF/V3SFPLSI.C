/*/  Function name:   v3sfpolsi3
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORDI data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfpolsi3(nvert, verti)

    unsigned short  nvert;
    V3COORDI  *verti;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0281;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);

    ioputfbuf(verti, 4 * nvert);
    }


