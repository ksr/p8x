/*/  Function name:  v3sfswire
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfswire(witype)

    unsigned short  witype;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02C2;
    *ptrbuff = witype;

    ioputbuf(buff, 2);
    }
