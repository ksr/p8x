/*/  Function name:   v3sfpols3
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfpols3(nvert, vert)

    unsigned short  nvert;
    V3COORD  *vert;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0280;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);

    ioputfbuf(vert, 3 * nvert);
    }


