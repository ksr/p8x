/*/  Function name:   v3sflight
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  LIGHT data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sflight(light_id, light)

    unsigned short  light_id;
    LIGHT  *light;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02D0;
    *ptrbuff = light_id;

    ioputbuf(buff, 2);

    ioputfbuf(light, 5);
    }


