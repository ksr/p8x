/*/  Function name:   v3sfpolsn3
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORDN data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3sfpolsn3(nvert, vertn)

    unsigned short  nvert;
    V3COORDN  *vertn;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0282;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);

    ioputfbuf(vertn, 6 * nvert);
    }


