/*/  Function name:   v3vwrotx
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3vwrotx(theta)

    ANGLE  theta;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00F3;
    *ptrbuff = theta;

    ioputbuf(buff, 2);
    }


