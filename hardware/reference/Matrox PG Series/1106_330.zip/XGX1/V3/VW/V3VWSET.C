/*/  Function name:   v3vwset
*
*    Author:   Jean Dupre
*    Date:     Oct 2, 1987
*
*    Modification history:  
*
*    Calls:     ioputw:  send a word to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"


void v3vwset(v)

    FIXPT  v[4][4];

    {
    ioputw(0x00F1);

    ioputfbuf(v, 16);
    }


