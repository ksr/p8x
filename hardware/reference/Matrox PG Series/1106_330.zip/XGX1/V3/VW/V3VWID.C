/*/  Function name:   v3vwid
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:   None
*/


void v3vwid()

    {
    ioputw(0x00F0);
    }


