/*/  Function name:   v3olplygn
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3olplygn(nvert, vertptr)

    unsigned short  nvert;
    V3COORD  *vertptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0107;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);
    ioputfbuf(vertptr, 3 * nvert);
    }


