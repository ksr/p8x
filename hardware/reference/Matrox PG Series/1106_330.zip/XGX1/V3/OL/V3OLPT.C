/*/  Function name:   v3olpt
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:   None
*/


void v3olpt()

    {
    ioputw(0x0102);
    }


