/*/  Function name:   v3olrlnto
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3olrlnto(deltx, delty, deltz)

    FIXPT  deltx, delty, deltz;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0104;

    LDFBUFF(ptrbuff, deltx);
    LDFBUFF(ptrbuff, delty);
    LDFBUFF(ptrbuff, deltz);

    ioputbuf(buff, 7);
    }


