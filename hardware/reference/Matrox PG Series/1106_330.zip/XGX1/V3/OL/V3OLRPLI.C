/*/  Function name:   v3olrpline
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V3COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3olrpline(ndelt, deltptr)

    unsigned short  ndelt;
    V3COORD  *deltptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0106;
    *ptrbuff = ndelt;

    ioputbuf(buff, 2);
    ioputfbuf(deltptr, 3 * ndelt);
    }


