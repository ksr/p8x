/*/  Function name:   v3ollnto
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3ollnto(x, y, z)

    FIXPT  x, y, z;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0103;

    LDFBUFF(ptrbuff, x);
    LDFBUFF(ptrbuff, y);
    LDFBUFF(ptrbuff, z);

    ioputbuf(buff, 7);
    }


