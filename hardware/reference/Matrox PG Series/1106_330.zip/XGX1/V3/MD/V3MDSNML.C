/*/  Function name:   v3mdsnml
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:     ioputw:  send a word to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"


void v3mdsnml(m)

    FIXPT  m[4][4];

    {
    ioputw(0x0291);

    ioputfbuf(m, 16);
    }


