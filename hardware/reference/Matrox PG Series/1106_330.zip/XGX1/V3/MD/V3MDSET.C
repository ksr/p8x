/*/  Function name:   v3mdset
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:     ioputw:  send a word to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"


void v3mdset(m)

    FIXPT  m[4][4];

    {
    ioputw(0x00DF);

    ioputfbuf(m, 16);
    }


