/*/  Function name:   v3mdid
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:   None
*/


void v3mdid()

    {
    ioputw(0x00DE);
    }


