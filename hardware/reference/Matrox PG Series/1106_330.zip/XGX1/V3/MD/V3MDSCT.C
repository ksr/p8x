/*/  Function name:   v3mdsct
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3mdsct(flag)

    BOOL  flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x02A7;
    *ptrbuff = flag;

    ioputbuf(buff, 2);
    }


