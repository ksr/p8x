/*/  Function name:  v3mdpush
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void v3mdpush()

    {
    ioputw(0x02AE);
    }


