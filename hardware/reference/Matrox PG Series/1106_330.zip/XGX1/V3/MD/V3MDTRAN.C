/*/  Function name:   v3mdtran
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3mdtran(tx, ty, tz)

    FIXPT  tx, ty, tz;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00E2;

    LDFBUFF(ptrbuff, tx);
    LDFBUFF(ptrbuff, ty);
    LDFBUFF(ptrbuff, tz);

    ioputbuf(buff, 7);
    }


