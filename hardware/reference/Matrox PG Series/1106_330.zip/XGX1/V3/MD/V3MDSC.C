/*/  Function name:   v3mdsc
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3mdsc(sx, sy, sz)

    FIXPT  sx, sy, sz;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00E1;

    LDFBUFF(ptrbuff, sx);
    LDFBUFF(ptrbuff, sy);
    LDFBUFF(ptrbuff, sz);

    ioputbuf(buff, 7);
    }


