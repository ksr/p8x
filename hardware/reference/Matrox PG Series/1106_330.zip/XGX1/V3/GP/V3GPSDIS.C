/*/  Function name:   v3gpsdist
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3gpsdist(dist)

    FIXPT  dist;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00D0;

    LDFBUFF(ptrbuff, dist);
    
    ioputbuf(buff, 3);
    }


