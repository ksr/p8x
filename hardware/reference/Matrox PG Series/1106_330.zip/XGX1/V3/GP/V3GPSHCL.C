/*/  Function name:   v3gpshclip
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v3gpshclip(flag)

    BOOL  flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00CD;
    *ptrbuff = flag;
    
    ioputbuf(buff, 2);
    }


