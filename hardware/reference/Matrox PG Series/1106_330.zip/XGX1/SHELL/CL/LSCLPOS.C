/*/  Function name:  lsclpos
*
*    Note:  Use the C binding's "iogetw" function to retrieve the data.
*           The low word is read first, then the high word.
*
*    Author:   Jean Dupre
*    Date:     Feb 5, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void lsclpos()

    {
    ioputw(0x000C);
    }


