/*/  Function name:  lsclloop
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclloop(command_list_num, number_times)

    unsigned short  command_list_num;
    short  number_times;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0004;
    *ptrbuff++ = command_list_num;
    *ptrbuff = number_times;

    ioputbuf(buff, 3);
    }


