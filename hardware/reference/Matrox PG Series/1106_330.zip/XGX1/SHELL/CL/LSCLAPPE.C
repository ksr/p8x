/*/  Function name:  lsclappend
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclappend(command_list_num, execute_flag)

    unsigned short  command_list_num;
    BOOL  execute_flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0007;
    *ptrbuff++ = command_list_num;
    *ptrbuff = execute_flag;

    ioputbuf(buff, 3);
    }


