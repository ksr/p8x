/*/  Function name:  lsclrealloc
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclrealloc(realloc_flag)

    BOOL  realloc_flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x000A;
    *ptrbuff = realloc_flag;

    ioputbuf(buff, 2);
    }


