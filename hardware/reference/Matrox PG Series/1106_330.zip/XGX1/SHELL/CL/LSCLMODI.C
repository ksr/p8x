/*/  Function name:  lsclmodify
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclmodify(command_list_num, word_offset, num_words, wordptr)

    unsigned short  command_list_num;
    short  word_offset;
    short  num_words;
    short  *wordptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0008;
    *ptrbuff++ = command_list_num;
    *ptrbuff++ = word_offset;
    *ptrbuff = num_words;

    ioputbuf(buff, 4);
    ioputbuf(wordptr, num_words);
    }


