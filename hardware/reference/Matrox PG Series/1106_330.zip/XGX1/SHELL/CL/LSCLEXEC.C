/*/  Function name:  lsclexec
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclexec(command_list_num)

    unsigned short  command_list_num;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0003;
    *ptrbuff = command_list_num;

    ioputbuf(buff, 2);
    }


