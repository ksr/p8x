/*/  Function name:  lsclsblksz
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsclsblksz(blk_size)

    unsigned long  blk_size;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0009;
    *ptrbuff++ = (unsigned short)blk_size;              /* low word  */
    *ptrbuff = (unsigned short)(blk_size >> 16);        /* high word */

    ioputbuf(buff, 3);
    }


