/*/  Function name:  lspken
*
*    Author:   Fancois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lspken(x,y,half_xsize,half_ysize)

    short  x, y;
    unsigned short  half_xsize, half_ysize;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0131;
    *ptrbuff++ = x;
    *ptrbuff++ = y;
    *ptrbuff++ = half_xsize;
    *ptrbuff = half_ysize;

    ioputbuf(buff, 5);
    }


