/*/  Function name:  lspksidl
*
*    Author:   Fancois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lspksidl(low_id)

    unsigned short  low_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0133;
    *ptrbuff = low_id;

    ioputbuf(buff, 2);
    }


