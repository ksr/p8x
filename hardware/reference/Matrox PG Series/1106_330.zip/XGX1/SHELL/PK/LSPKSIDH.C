/*/  Function name:  lspksidh
*
*    Author:   Fancois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lspksidh(hi_id)

    unsigned short  hi_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0134;
    *ptrbuff = hi_id;

    ioputbuf(buff, 2);
    }


