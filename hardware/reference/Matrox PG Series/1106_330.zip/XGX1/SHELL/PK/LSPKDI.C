/*/  Function name:  lspkdi
*
*    Author:   Fancois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void lspkdi()

    {
    ioputw(0x0132);
    }


