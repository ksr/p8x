/*/  Function name:  lslutrs
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutrs(def_lut, log_lut)

    short  def_lut;
    unsigned short  log_lut;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0035;
    *ptrbuff++ = def_lut;
    *ptrbuff = log_lut;

    ioputbuf(buff, 3);
    }


