/*/  Function name:  lslutpm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutpm(phy_lut, bitmask)

    unsigned short  phy_lut;
    unsigned short  bitmask;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0125;
    *ptrbuff++ = phy_lut;
    *ptrbuff = bitmask;

    ioputbuf(buff, 3);
    }


