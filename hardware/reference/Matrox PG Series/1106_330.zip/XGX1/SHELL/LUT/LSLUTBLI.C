/*/  Function name:  lslutblink
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"
 
IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutblink(phy_lut, index, r, g, b, offtime, ontime)

    unsigned short  phy_lut;
    unsigned short  index;
    unsigned short  r, g, b;
    unsigned short  offtime, ontime;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0126;
    *ptrbuff++ = phy_lut;
    *ptrbuff++ = index;
    *ptrbuff++ = r;
    *ptrbuff++ = g;
    *ptrbuff++ = b;
    *ptrbuff++ = offtime;
    *ptrbuff = ontime;

    ioputbuf(buff, 8);
    }


