/*/  Function name:  lslutmd
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  LUTVAL data structure.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutmd(log_lut, first_entry, nentries, colors)

    unsigned short  log_lut;
    unsigned short  first_entry;
    unsigned short  nentries;
    LUTVAL  *colors;    

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0033;
    *ptrbuff++ = log_lut;
    *ptrbuff++ = first_entry;
    *ptrbuff = nentries;

    ioputbuf(buff, 4);
    ioputbuf(colors, 3 * nentries);
    }


