/*/  Function name:  lslutsblink
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void lslutsblink()


    {
    ioputw(0x0127);
    }


