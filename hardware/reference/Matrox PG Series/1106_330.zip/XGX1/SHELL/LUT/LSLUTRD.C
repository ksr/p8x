/*/  Function name:  lslutrd
*
*    Note:  Use the C binding's "iogetbuf" function to retrieve the data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutrd(log_lut, first_entry, nentries)

    unsigned short  log_lut;
    unsigned short  first_entry;
    unsigned short  nentries;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0034;
    *ptrbuff++ = log_lut;
    *ptrbuff++ = first_entry;
    *ptrbuff = nentries;

    ioputbuf(buff, 4);
    }


