/*/  Function name:  lslutsl
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lslutsl(log_lut, phy_lut)

    unsigned short  log_lut;
    unsigned short  phy_lut;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0032;
    *ptrbuff++ = log_lut;
    *ptrbuff = phy_lut;

    ioputbuf(buff, 3);
    }


