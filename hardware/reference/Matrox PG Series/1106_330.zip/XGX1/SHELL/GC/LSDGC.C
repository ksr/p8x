/*/  Function name:  lsdgc
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BITMAP data structure.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsdgc(cursor_id, xhot, yhot, gc_bmapptr)

    unsigned short  cursor_id;
    short  xhot, yhot;
    BITMAP  *gc_bmapptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x007F;
    *ptrbuff++ = cursor_id;
    *ptrbuff++ = xhot;
    *ptrbuff = yhot;

    ioputbuf(buff, 4);
    ioputbuf(gc_bmapptr, 4);
    ioputbuf(gc_bmapptr->tl, 2 * gc_bmapptr->h * gc_bmapptr->pitch);
    }


