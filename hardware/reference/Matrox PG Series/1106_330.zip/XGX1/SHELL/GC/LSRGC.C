/*/  Function name:  lsrgc
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrgc(cursor_id)

    unsigned short  cursor_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0081;
    *ptrbuff = cursor_id;

    ioputbuf(buff, 2);
    }


