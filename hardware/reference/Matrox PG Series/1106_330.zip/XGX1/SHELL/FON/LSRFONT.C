/*/  Function name:  lsrfont
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrfont(font_id)

    unsigned short  font_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0067;
    *ptrbuff = font_id;

    ioputbuf(buff, 2);
    }


