/*/  Function name:  lsdfont
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FONT data structure.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsdfont(font_id, font_ptr)

    unsigned short  font_id;
    FONT  *font_ptr;

    {
    unsigned short  length_owtable = 0;
    unsigned short  length_data = font_ptr->pitch;

    if (!font_ptr->width)           /* Proportional-spaced font */
        length_owtable = font_ptr->lastch_off + 2;

    if (font_ptr->fmt & 0x0001)     /* Raster font */
        length_data *= font_ptr->height;
    else                            /* Stroke font */
        length_owtable += font_ptr->lastch_off + 2;

    ptrbuff = buff;

    *ptrbuff++ = 0x0065;
    *ptrbuff = font_id;

    ioputbuf(buff, 2);
    ioputbuf(font_ptr, 13);

    if (length_owtable)
        ioputbuf(font_ptr->owtable, length_owtable);

    ioputbuf(font_ptr->kerntable, font_ptr->nkpairs);
    ioputbuf(font_ptr->data, length_data);
    }


