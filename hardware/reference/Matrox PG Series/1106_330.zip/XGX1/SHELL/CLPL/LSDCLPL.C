/*/  Function name:  lsdclpl
*
*    Author:   Francois Vigneautl
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsdclpl(id,num_clpr,clip_ptr)

    short  id;
    unsigned short num_clpr;
    short *clip_ptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0136;
    *ptrbuff++ = id;
    *ptrbuff = num_clpr;
    ioputbuf(buff, 3);

    while(num_clpr--)
        {
        ioputw(*clip_ptr++);
        ioputw(*clip_ptr++);
        ioputw(*clip_ptr++);
        ioputw(*clip_ptr++);
        }
    }


