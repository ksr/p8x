/*/  Function name:  lsrclpl
*
*    Author:   Francois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrclpl(id)

    short  id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0138;
    *ptrbuff = id;

    ioputbuf(buff, 2);
    }


