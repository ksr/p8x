/*/  Function name:  lstgrlay
*
*    Author:   Francois Souchay
*    Date:     Feb 13, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lstgrlay( cl_id, layer_id )

    unsigned short cl_id;
    unsigned long layer_id;
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0143;
    *ptrbuff++ = cl_id;
    *ptrbuff   = layer_id;

    ioputbuf(buff, 3);
    }


