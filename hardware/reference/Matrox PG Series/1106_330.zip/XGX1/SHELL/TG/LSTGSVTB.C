/*/  Function name:  lstgsvtb
*
*    Author:   Francois Souchay
*    Date:     Feb 13, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lstgsvtbl( vtable )

    unsigned short vtable[];
    {
	 ioputw( 0x0145 );
    ioputbuf(vtable, 16);
    }


