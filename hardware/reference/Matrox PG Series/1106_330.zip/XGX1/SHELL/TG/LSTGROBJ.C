/*/  Function name:  lstgrobj
*
*    Author:   Francois Souchay
*    Date:     Feb 13, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lstgrobj( cl_id, obj_id )

    unsigned short cl_id;
    unsigned long obj_id;
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0142;
    *ptrbuff++ = cl_id;
    *ptrbuff++ = (unsigned short)obj_id;              /* low word  */
    *ptrbuff   = (unsigned short)(obj_id >> 16);      /* high word */

    ioputbuf(buff, 4);
    }


