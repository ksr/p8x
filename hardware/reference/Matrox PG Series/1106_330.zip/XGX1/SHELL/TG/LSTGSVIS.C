/*/  Function name:  lstgsvis
*
*    Author:   Francois Souchay
*    Date:     Feb 13, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lstgsvis( layer_id, vis_flag )

    unsigned short layer_id;
    unsigned short vis_flag;
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0144;
    *ptrbuff++ = layer_id;
    *ptrbuff   = vis_flag;

    ioputbuf(buff, 3);
    }


