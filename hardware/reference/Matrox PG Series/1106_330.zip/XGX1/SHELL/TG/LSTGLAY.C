/*/  Function name:  lstglay
*
*    Author:   Francois Souchay
*    Date:     Feb 13, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lstglay( layer_id )

    unsigned short layer_id;
    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0141;
    *ptrbuff   = layer_id;

    ioputbuf(buff, 2);
    }


