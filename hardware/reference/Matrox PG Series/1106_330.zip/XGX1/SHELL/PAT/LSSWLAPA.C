/*/  Function name:  lsswlapat
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsswlapat(apat_id)

    short  apat_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x003B;
    *ptrbuff = apat_id;

    ioputbuf(buff, 2);
    }


