/*/  Function name:  lsrapat
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrapat(apat_id)

    unsigned short  apat_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x005A;
    *ptrbuff = apat_id;

    ioputbuf(buff, 2);
    }


