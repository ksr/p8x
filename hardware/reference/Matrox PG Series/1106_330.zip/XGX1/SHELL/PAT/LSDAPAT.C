/*/  Function name:  lsdapat
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BITMAP data structure.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsdapat(fillpat_id, fillpat_ptr)

    unsigned short  fillpat_id;
    BITMAP  *fillpat_ptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0058;
    *ptrbuff = fillpat_id;

    ioputbuf(buff, 2);
    ioputbuf(fillpat_ptr, 4);

    if (fillpat_ptr->pitch)
        ioputbuf(fillpat_ptr->tl, fillpat_ptr->h * fillpat_ptr->pitch);
    else
        ioputbuf(fillpat_ptr->tl, 2);
    }


