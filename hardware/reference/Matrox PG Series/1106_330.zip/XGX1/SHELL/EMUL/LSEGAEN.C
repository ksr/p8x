/*/  Function name:  lsegaen
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsegaen(mode)

    unsigned short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x012E;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


