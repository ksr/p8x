/*/  Function name:  lsvgasw
*
*    Author:   Alice Kim
*    Date:     July 16, 1990
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsvgasw(mode)

    unsigned short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x013b;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


