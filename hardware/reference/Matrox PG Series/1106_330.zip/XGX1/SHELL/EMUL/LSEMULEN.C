/*/  Function name:  lsemulen
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BOOL data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsemulen(restore_flag)

    BOOL  restore_flag;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0124;
    *ptrbuff = restore_flag;

    ioputbuf(buff, 2);
    }


