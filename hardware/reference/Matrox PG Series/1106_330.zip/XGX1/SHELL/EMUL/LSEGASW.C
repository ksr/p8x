/*/  Function name:  lsegasw
*
*    Author:   Francois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsegasw(mode)

    unsigned short  mode;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0139;
    *ptrbuff = mode;

    ioputbuf(buff, 2);
    }


