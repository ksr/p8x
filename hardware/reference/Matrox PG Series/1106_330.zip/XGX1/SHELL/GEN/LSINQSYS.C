/*/  Function name:  lsinqsys
*
*    Note:  Use the C binding's "iogetbuf" function to retrieve the data.
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void lsinqsys()

    {
    ioputw(0x012F);
    }


