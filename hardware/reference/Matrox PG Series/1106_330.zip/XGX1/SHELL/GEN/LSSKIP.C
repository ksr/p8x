/*/  Function name:  lsskip
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsskip(num_words)

    unsigned short  num_words;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0120;
    *ptrbuff = num_words;

    ioputbuf(buff, 2);
    }


