/*/  Function name:  lsrdrst
*
*    Note:  The user must be sure that the read fifo is empty before sending
*           that command.
*
*    Author:   Jean Dupre
*    Date:     Feb 15, 1988
*
*    Modification history:  
*              Alice Kim     July 16, 1990
*              Removed LOCAL unsigned short  tempbuff[TEMPBUFFSIZE]; use
*              buff[] instead (defined in lsinit.c)
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*            iogetbuf:  get a buffer of words from the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"
#include  <stdio.h>


IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrdrst(left, top, right, bottom, dest_filename)

    short  left, top, right, bottom;
    char  dest_filename[];

    {
    FILE    *fpw;                          /* Output file pointer */
    unsigned long  length;
    unsigned short  numwrite;

    ptrbuff = buff;

    *ptrbuff++ = 0x0020;
    *ptrbuff++ = left;
    *ptrbuff++ = top;
    *ptrbuff++ = right;
    *ptrbuff = bottom;

    ioputbuf(buff, 5);

    length = ((long)(right - left + 1) * (long)(bottom - top + 1) + 1) >> 1;

    fpw = fopen(dest_filename, "wb");

    while (length)
        {
        if (length > CBUFFLENGTH)
            {
            numwrite = CBUFFLENGTH;
            length -= CBUFFLENGTH;
            }
        else
            {
            numwrite = length;
            length = 0;
            }

        iogetbuf( (unsigned short *)buff, numwrite);

        fwrite((char *)buff, sizeof(short), numwrite, fpw);
        }

    fclose(fpw);
    }


