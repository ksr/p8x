/*/  Function name:  lsinq
*
*    Note:  This function will return in the read fifo a variable number of
*           words depending on the inquiery parameters requested.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsinq(inq_code)

    unsigned short  inq_code;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0130;
    *ptrbuff = inq_code;

    ioputbuf(buff, 2);
    }


