/*/  Function name:  lsinqmem
*
*    Note:  Use the C binding's "iogetw" function to retrieve data.
*           The low word is read first, then the high word.
*
*    Author:   Jean Dupre
*    Date:     Jan 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void lsinqmem()

    {
    ioputw(0x000B);
    }


