/*/  Function name:  lswrrst
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*              Alice Kim     July 16, 1990
*              Removed LOCAL unsigned short  tempbuff[TEMPBUFFSIZE]; used
*              buff[] instead (defined in lsinit.c)
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  -1: if the routine is not able to open the file
*                    0: otherwise
*/

#include  "def.h"
#include  <stdio.h>


IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


short lswrrst(left, top, right, bottom, src_filename)

    short  left, top, right, bottom;
    char  src_filename[];

    {
    FILE    *fpr;                          /* Input file pointer */
    unsigned long  length;
    unsigned short  numread;

    ptrbuff = buff;

    *ptrbuff++ = 0x001F;
    *ptrbuff++ = left;
    *ptrbuff++ = top;
    *ptrbuff++ = right;
    *ptrbuff = bottom;

    ioputbuf(buff, 5);

    if ((fpr = fopen(src_filename, "rb")) == NULL)
        return(-1);

    length = ((long)(right - left + 1) * (long)(bottom - top + 1) + 1) >> 1;

    while (length)
        {
        if (length > CBUFFLENGTH)
            {
            numread = CBUFFLENGTH;
            length -= CBUFFLENGTH;
            }
        else
            {
            numread = length;
            length = 0;
            }

        fread((char *)buff, sizeof(short), numread, fpr);

        ioputbuf(buff, numread);
        }

    fclose(fpr);

    return(0);
    }


