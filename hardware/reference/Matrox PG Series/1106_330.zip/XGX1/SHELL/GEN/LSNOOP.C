/*/  Function name:  lsnoop
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void lsnoop()

    {
    ioputw(0x0122);
    }


