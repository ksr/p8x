/*/  Function name:  lsinqgcp
*
*    Note:  Use the C binding's "iogetw" function to retrieve the data.
*           Returns current position of graphics cursor in screen coords.
*           The x-coord is returned first, followed by y-coord.
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/


void lsinqgcp()

    {
    ioputw(0x0087);
    }


