/*/  Function name:  lsvsint
*
*    Author:   Francois Vingeault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsvsint(frames)

    unsigned short  frames;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0135;
    *ptrbuff = frames;

    ioputbuf(buff, 2);
    }


