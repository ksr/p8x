/*/  Function name:  lsswpvar
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsswpvar(tot_space, no_words)

    short  tot_space;
    short  no_words;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0076;
    *ptrbuff++ = tot_space;
    *ptrbuff = no_words;

    ioputbuf(buff, 3);
    }


