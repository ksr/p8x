/*/  Function name:  lswait
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lswait(frames)

    unsigned short  frames;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0121;
    *ptrbuff = frames;

    ioputbuf(buff, 2);
    }


