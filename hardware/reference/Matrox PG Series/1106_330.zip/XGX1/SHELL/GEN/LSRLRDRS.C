/*/  Function name:  lsrlrdrst
*
*    Note:  The user must be sure that the read fifo is empty before sending
*           that command.
*
*    Author:   Jean Dupre
*    Date:     Feb 15, 1988
*
*    Modification history:  
*
*					Andre Allore	March 7/1989
*										use "iogetu()" to get an unsigned
*					short and avoid sign extension when typecasting as an
*              (unsigned long).
*
*              Alice Kim     July 16, 1990
*              Replaced "iogetu()" with "iogetw()"
*              Removed LOCAL unsigned short  tempbuff[TEMPBUFFSIZE]; used
*              buff[] instead (defined in lsinit.c)
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*            iogetbuf:  get a buffer of words from the board.
*
*    Uses:  None
*
*    Return value:  None
*/


#include	 "libfn.h"
#include  "def.h"
#include  <stdio.h>

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrlrdrst(left, top, right, bottom, dest_filename)

    short  left, top, right, bottom;
    char  dest_filename[];

    {
    FILE    *fpw;                          /* Output file pointer */
    unsigned long  length;
    unsigned short  numwrite;

    ptrbuff = buff;

    *ptrbuff++ = 0x0037;
    *ptrbuff++ = left;
    *ptrbuff++ = top;
    *ptrbuff++ = right;
    *ptrbuff = bottom;

    ioputbuf(buff, 5);

    length = (unsigned long) iogetw();
    length |= (unsigned long) iogetw() << 16;

    fpw = fopen(dest_filename, "wb");

    while (length)
        {
        if (length > CBUFFLENGTH)
            {
            numwrite = CBUFFLENGTH;
            length -= CBUFFLENGTH;
            }
        else
            {
            numwrite = length;
            length = 0;
            }

        iogetbuf( (unsigned short *)buff, numwrite);

        fwrite((char *)buff, sizeof(short), numwrite, fpw);
        }

    fclose(fpw);
    }


