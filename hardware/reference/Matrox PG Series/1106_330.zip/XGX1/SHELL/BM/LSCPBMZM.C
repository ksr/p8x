/*/  Function name:  lscpbmzm
*
*    Author:   Andre Allore
*    Date:     February 17, 1989
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lscpbmzm(spx, spy, dpx, dpy, sizex, sizey, zoomx, zoomy)

    short  spx, spy;
    short  dpx, dpy;
    unsigned short  sizex, sizey;
	 FIXPT zoomx, zoomy;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x011E;
    *ptrbuff++ = spx;
    *ptrbuff++ = spy;
    *ptrbuff++ = dpx;
    *ptrbuff++ = dpy;
    *ptrbuff++ = sizex;
    *ptrbuff++ = sizey;

    LDFBUFF(ptrbuff, zoomx);
    LDFBUFF(ptrbuff, zoomy);
 
    ioputbuf(buff, 11);
    }


