/*/  Function name:  lssbm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lssbm(bm_id)

    short  bm_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0129;
    *ptrbuff = bm_id;

    ioputbuf(buff, 2);
    }


