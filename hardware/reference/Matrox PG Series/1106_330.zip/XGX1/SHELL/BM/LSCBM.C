/*/  Function name:  lscbm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  BITMAP data structure.
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lscbm(bm_id, bm_spec_ptr)

    unsigned short  bm_id;
    BITMAP  *bm_spec_ptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0128;
    *ptrbuff = bm_id;

    ioputbuf(buff, 2);
    ioputbuf(bm_spec_ptr, 4);
    }


