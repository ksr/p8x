/*/  Function name:  lsfbm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:    ioputw:  send a word to the board.
*            ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"


void lsfbm(bm_length, bm_data_ptr)

    unsigned short  bm_length;
    unsigned short  *bm_data_ptr;

    {
    ioputw(0x012A);

    ioputbuf(bm_data_ptr, bm_length);
    }


