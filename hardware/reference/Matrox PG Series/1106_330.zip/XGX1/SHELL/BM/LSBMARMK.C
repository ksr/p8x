/*/  Function name:  lsbmarmsk
*
*    Author:   Fancois Vigneault
*    Date:     July 22, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsbmarmsk(spx, spy, dpx, dpy, sizex, sizey)

    short  spx, spy;
    short  dpx, dpy;
    unsigned short  sizex, sizey;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x011F;
    *ptrbuff++ = spx;
    *ptrbuff++ = spy;
    *ptrbuff++ = dpx;
    *ptrbuff++ = dpy;
    *ptrbuff++ = sizex;
    *ptrbuff = sizey;

    ioputbuf(buff, 7);
    }


