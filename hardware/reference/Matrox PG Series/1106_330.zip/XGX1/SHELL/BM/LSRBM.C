/*/  Function name:  lsrbm
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void lsrbm(bm_id)

    unsigned short  bm_id;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x012D;
    *ptrbuff = bm_id;

    ioputbuf(buff, 2);
    }


