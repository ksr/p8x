/*/  Function name:   v2txstring
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2txstring(x, y, strptr)

    FIXPT  x, y;
    short  *strptr;

    {
    unsigned short  length = 0;
    short  *ptrtxt;

    ptrtxt = strptr;

    while (*ptrtxt++)
        length++;

    ptrbuff = buff;

    *ptrbuff++ = 0x008E;
    LDFBUFF(ptrbuff, x);
    LDFBUFF(ptrbuff, y);
    *ptrbuff = length;

    ioputbuf(buff, 6);

    ioputbuf(strptr, length);
    }


