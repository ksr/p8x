/*/  Function name:   v2txbstring
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*            ioputtxt:  send a text string to the board.
*
*    Uses:  FIXTP data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2txbstring(x, y, strptr)

    FIXPT  x, y;
    char  *strptr;

    {
    unsigned short  length = strlen(strptr);

    ptrbuff = buff;

    *ptrbuff++ = 0x008E;
    LDFBUFF(ptrbuff, x);
    LDFBUFF(ptrbuff, y);
    *ptrbuff = length;

    ioputbuf(buff, 6);

    ioputtxt(strptr, length);
    }


