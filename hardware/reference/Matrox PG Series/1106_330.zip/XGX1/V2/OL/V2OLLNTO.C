/*/  Function name:   v2ollnto
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2ollnto(x, y)

    FIXPT  x, y;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00A2;

    LDFBUFF(ptrbuff, x);
    LDFBUFF(ptrbuff, y);
    
    ioputbuf(buff, 5);
    }


