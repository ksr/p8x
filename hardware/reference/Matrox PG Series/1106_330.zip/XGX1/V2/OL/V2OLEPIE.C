/*/  Function name:   v2olepie
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  ANGLE data type.
*           FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olepie(sth, eth, a, b)

    ANGLE  sth, eth;
    FIXPT  a, b;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00A8;
    *ptrbuff++ = sth;
    *ptrbuff++ = eth;

    LDFBUFF(ptrbuff, a);
    LDFBUFF(ptrbuff, b);
    
    ioputbuf(buff, 7);
    }


