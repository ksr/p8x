/*/  Function name:   v2olsw
*
*    Author:   Jean Dupre
*    Date:     April 4, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olsw(width)

    FIXPT  width;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0095;
    LDFBUFF(ptrbuff, width);

    ioputbuf(buff, 3);
    }


