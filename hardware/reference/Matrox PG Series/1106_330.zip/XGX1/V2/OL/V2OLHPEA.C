/*/  Function name:   v2olhpearc
*
*    Author:   Jean Dupre
*    Date:     March 15, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olhpearc(sth, eth, a, b)

    FIXPT  sth, eth;
    FIXPT  a, b;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00AE;

    LDFBUFF(ptrbuff, sth);
    LDFBUFF(ptrbuff, eth);
    LDFBUFF(ptrbuff, a);
    LDFBUFF(ptrbuff, b);
    
    ioputbuf(buff, 9);
    }


