/*/  Function name:   v2olpt
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:   None
*/


void v2olpt()

    {
    ioputw(0x00A1);
    }


