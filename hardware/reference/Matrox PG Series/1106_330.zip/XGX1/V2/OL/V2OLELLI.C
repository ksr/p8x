/*/  Function name:   v2olellipse
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olellipse(a, b)

    FIXPT  a, b;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00A6;

    LDFBUFF(ptrbuff, a);
    LDFBUFF(ptrbuff, b);
    
    ioputbuf(buff, 5);
    }


