/*/  Function name:   v2olplygn
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:   ioputbuf:  send a buffer of words to the board.
*            ioputfbuf:  send a buffer of floats to the board.
*
*    Uses:  V2COORD data structure.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olplygn(nvert, vertptr)

    unsigned short  nvert;
    V2COORD  *vertptr;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00AC;
    *ptrbuff = nvert;

    ioputbuf(buff, 2);
    ioputfbuf(vertptr, 2 * nvert);
    }


