/*/  Function name:   v2olrmvto
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2olrmvto(deltx, delty)

    FIXPT  deltx, delty;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00A0;

    LDFBUFF(ptrbuff, deltx);
    LDFBUFF(ptrbuff, delty);
    
    ioputbuf(buff, 5);
    }


