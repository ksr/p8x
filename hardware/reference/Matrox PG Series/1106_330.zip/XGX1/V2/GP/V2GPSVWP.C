/*/  Function name:   v2gpsvwp
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  None
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2gpsvwp(xmin, xmax, ymin, ymax)

    short  xmin, xmax;
    short  ymin, ymax;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0090;
    *ptrbuff++ = xmin;
    *ptrbuff++ = xmax;
    *ptrbuff++ = ymin;
    *ptrbuff = ymax;
    
    ioputbuf(buff, 5);
    }


