/*/  Function name:  v2gppushwdw
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void v2gppushwdw()

    {
    ioputw(0x02A9);
    }


