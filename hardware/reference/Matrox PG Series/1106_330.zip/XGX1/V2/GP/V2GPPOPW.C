/*/  Function name:  v2gppopwdw
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void v2gppopwdw()

    {
    ioputw(0x02A8);
    }


