/*/  Function name:  v2gppushvwp
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void v2gppushvwp()

    {
    ioputw(0x02AB);
    }


