/*/  Function name:   v2gpmapx
*
*    Note:  Use the C binding's "iogetw" function to retrieve the data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2gpmapx(x)

    FIXPT  x;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0092;

    LDFBUFF(ptrbuff, x);
    
    ioputbuf(buff, 3);
    }


