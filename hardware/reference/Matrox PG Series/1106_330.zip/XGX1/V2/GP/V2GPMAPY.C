/*/  Function name:   v2gpmapy
*
*    Note:  Use the C binding's "iogetw" function to retrieve the data.
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2gpmapy(y)

    FIXPT  y;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x0093;

    LDFBUFF(ptrbuff, y);
    
    ioputbuf(buff, 3);
    }


