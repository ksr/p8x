/*/  Function name:  v2gppopvwp
*
*    Author:   Jean Dupre
*    Date:     March 16, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:  None
*/

void v2gppopvwp()

    {
    ioputw(0x02AA);
    }


