/*/  Function name:   v2arrrect
*
*    Author:   Jean Dupre
*    Date:     March 17, 1988
*
*    Modification history:  
*
*    Calls:  ioputbuf:  send a buffer of words to the board.
*
*    Uses:  FIXPT data type.
*
*    Return value:   None
*/

#include  "def.h"

IMPORT  short  buff[];
IMPORT  short  *ptrbuff;


void v2arrrect(deltx, delty)

    FIXPT  deltx, delty;

    {
    ptrbuff = buff;

    *ptrbuff++ = 0x00B9;

    LDFBUFF(ptrbuff, deltx);
    LDFBUFF(ptrbuff, delty);
    
    ioputbuf(buff, 5);
    }


