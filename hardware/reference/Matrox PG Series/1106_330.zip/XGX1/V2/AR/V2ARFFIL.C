/*/  Function name:   v2arffill
*
*    Author:   Jean Dupre
*    Date:     Feb 8, 1988
*
*    Modification history:  
*
*    Calls:  ioputw:  send a word to the board.
*
*    Uses:  None
*
*    Return value:   None
*/


void v2arffill()

    {
    ioputw(0x00C1);
    }


