/*/  Function name:  iogetfbuf
*
*    Synopsis:  Get a buffer of floats from the board FIFO.
*
*    Author:   Andre Allore
*    Date:     March 21, 1989
*
*    Modification history:
*
*    Calls:  rdfifocnt: get read FIFO count.
*
*    Uses:  Global variable "ioseg" and "device".
*				FIXPT data type.
*
*    Return value:  None
*/

#include "def.h"
#include "iolib.h"


/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;


/* Reference to the address structure of the board */

IMPORT  struct pg_com far  *ioseg;


/*	Reference to read FIFO count function */

IMPORT  short rdfifocnt();

	
void iogetfbuf(buffer, nfloats)

		FIXPT *buffer;
		unsigned short nfloats;

		{

		short count, words;
		long val;

		if (device)
			{
			while (nfloats)
 				{
 				if (nfloats * 2 > HLFFIFO_SIZE)
 					words = QTRFIFO_SIZE;
	 			else
					words = nfloats;
				nfloats -= words;

				count = rdfifocnt();		 	   /* get read FIFO count */ 
				while (count < 2 * words)		/* loop while FIFO is filling */
					count = rdfifocnt();		 	/* get read FIFO count */ 

				while (words-- > 0)
					{
					val = (unsigned long) (unsigned short) ioseg->fifo; /* get fractional part */
					val += (long) ioseg->fifo << 16;							 /* get integer part */
					*buffer++ = (float)(val) / 65536.0;
					}
				}
			}
		else
         {
         printf("iogetfbu:  readback invalid from a file\n");
         exit(-1);
         } 
		}
	
