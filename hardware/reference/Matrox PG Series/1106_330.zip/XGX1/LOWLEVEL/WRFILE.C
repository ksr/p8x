/*/  Function name:  wrfile
*
*    Synopsis:  Write words into an output file.
*
*    Author:   Jean Dupre
*    Date:     Nov 18, 1987
*
*    Modification history:   
*
*    Calls:  None
*
*    Uses:  Global variable "pgcfile".
*
*    Return value:  None
*/


#include  "def.h"


/* Reference to output file handle */

IMPORT short  pgcfile;



void wrfile(val)

    short  val;

    {
    if (write(pgcfile, &val, 2) == -1)
        {
        printf("Not able to write in the output file");
        exit(-1);
        }
    }




