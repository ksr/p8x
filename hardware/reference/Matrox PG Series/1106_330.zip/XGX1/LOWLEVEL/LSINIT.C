/*/  Function name:  lsinit
*
*	  Synopsis:  Initialize all the PG-1281's in the system, by first getting
*					 the base addresses of all boards from the environment variable
*					 PG-1281, and then testing each board at its base address.
*
*					 If no environment variable exists, then lsinit will function
*					 in the usual manner.
*
*    Author:   Marc Fortier
*    Date:     April 10, 1989
*
*    Modification history:   
*                            
*
*    Calls:  chk_board : check for the presence of the board at the selected
*                     address.
*				 get_environment_data: get base addresses from environment variable.
*
*
*    Uses:  Global variables "pgcfile" and "ioseg".
*
*    Return value:  None
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include  "def.h"
#include  "iolib.h"

#define   CBUFFLENGTH   1024

/* Buffer reserved for transfers between the PG-1281 C binding library */
/* and the board.                                                      */

short  buff[CBUFFLENGTH];     

/* Pointer to shorts (16 bits signed integer) */

short  *ptrbuff;

/* The output device value; file (device=0), C6000H (device=1), C6400H (device=2) */

short	 device = 0;

/* The file that output is written to */

short  pgcfile = 0;

/* Definition of the address structure of the board */

struct pg_com far  *ioseg = 0;

/* multiple board addressing parameters */

#define DEF_ADDR   0xC6000000
#define ALT_ADDR_1 0xC6400000
#define ALT_ADDR_2 0xCE000000
#define ALT_OFFSET 0x400000

#define MAXBOARD 10			/* maximum 10 boards in a system */
unsigned long address_array[ MAXBOARD ] = { DEF_ADDR,0,0,0,0,0,0,0,0,0 };
unsigned long address_list[] = { 0xC6000000, 0xCA000000, 0xCE000000,
					  						0xD2000000, 0xD4000000, 0xD6000000,
											0xDE000000, 0xE2000000, 0xE4000000,
											0xF6000000 };  /* permissable addresses */

unsigned num_boards = 0;   /* number of boards in system */

/* global count for fifo freedom */

short   globcnt = 0;
short   fifo_count[ MAXBOARD ] = {0,0,0,0,0,0,0,0,0,0};


/*------------------------------------------------------------------------*/

short checklist( unsigned long env_address )

/*   Checks if the environment address is in the list of permissable
	 addresses.

	 Inputs: the environment address to be checked

	 Uses: address_list[], array of permissable addresses.

	 Return value: non-Null if address is no good, Null if OK.
*/
	 
{
	short i = 0;

	while( i < MAXBOARD )
	{
	 	if(  ( env_address == address_list[i] ) ||
			  ( env_address == address_list[i] + ALT_OFFSET) )
			return( NULL );  /* match was found - address OK */
		i ++;
	}
	return( 1 );  /* no match, bad address */
}

/*------------------------------------------------------------------------*/

unsigned short get_environment_data()

/*   This function gets the environment string pg1281, and parses it into
	 base addresses.  If any of the base addresses are invalid, the program
	 terminates with an error.

	 Inputs: None.

	 Calls: checklist(): verify that the address is valid

	 Return value: The number of boards declared in the environment

*/

{
	char *env_data;
	char *env_copy;
	char *addr_token;
	char *end_ptr;
	unsigned short env_num = 0;
	unsigned long env_address;
	short checklist(), error;

	/* get and parse the environment string */

	if ( (env_data = getenv( "PG1281" )) != NULL )
	/* PG1281 environment string declared, fill address array */
	{
		env_copy = ( char * ) malloc( 128 );  /* maximum dos line is 128 */
		strcpy( env_copy, env_data );  /* make a copy of the environment string */

		addr_token = strtok( env_copy, " ,;+\0" );
		while( addr_token != NULL )
		{
			env_address = strtoul( addr_token, &end_ptr, 0 ) << 16;
			error = checklist( env_address );
			if( error )
			{
				printf( "\nBad environment address value: %s\n", addr_token );
				exit( -1 );
			}
			else
				address_array[ env_num ++ ] = env_address;
			addr_token = strtok( NULL, " ,;+\0" );
	 	}  /* env_num addresses were specified */
		if( env_num > 10 )
		{
			printf( "\nToo many environment addresses declared, maximum is " );
			printf( "MAXBOARD\n" );
			exit( -1 );
		}
		else
			return( env_num );
	}
	else  /* no environment string */
		return( NULL );
}

/*------------------------------------------------------------------------*/

#define   REG1   0xC0000130
#define   REG2   0xC0000140

unsigned long chk_board( short board_num )

/*  Attempts to initialize the given board number at its base address.
	 Exits program if unsuccessful.

	 Return value: the base address.
*/

{
    unsigned short  status;
    unsigned short  temp1, temp2;
    unsigned short  read1, read2;

	 if( board_num && (board_num >= num_boards) ) 
	 {
		 printf( "\nError: Board select number '%d' is not valid.\n", board_num );
		 exit( -1 );
	 }

	 ioseg = ( struct pg_com far * ) address_array[ board_num ];

    /* Stop the GSP */
    status = ioseg->hstctrl;
    ioseg->hstctrl = status | 0x8000;

    /* Test if the PG-1281 is at the right address */

    ioseg->hstaddr = (unsigned long)REG1;
    temp1 = ioseg->hstdata;
    ioseg->hstdata = 0x5A5A;

    ioseg->hstaddr = (unsigned long)REG2;
    temp2 = ioseg->hstdata;
    ioseg->hstdata = 0xA5A5;

    ioseg->hstaddr = (unsigned long)REG1;
    read1 = ioseg->hstdata;
    ioseg->hstaddr = (unsigned long)REG2;
    read2 = ioseg->hstdata;

    if ((read1 != 0x5A5A) || (read2 != 0xA5A5))
    {
     	  printf("\nBoard not responding at address ");
	     printf("0x%lX ... re-download LIB SHELL to continue.\n",
			  		 (address_array[ board_num ] >> 12) );
        exit(-1);
    }

    ioseg->hstaddr = (unsigned long)REG1;
    ioseg->hstdata = temp1;
    ioseg->hstaddr = (unsigned long)REG2;
    ioseg->hstdata = temp2;

    /* Restart the GSP */
    ioseg->hstctrl = status;
 	 return( address_array[ board_num ] );
}

/*------------------------------------------------------------------------*/

void lsinit( short fhandle, short addr )
{
	unsigned short i, get_environment_data();
	unsigned long chk_board( short );

	device = addr & 3;        /* device is either a file or a board */
                              /* only bits 0-1 are required */

	if ( fhandle == 0 )             /* If fhandle is 0, initialize pg1281's */
	{
		pgcfile = 0;

		num_boards = get_environment_data();
		if( num_boards > 1 )  /* multiple boards declared in environment */
		{
			for( i = 0; i < num_boards ; i ++ )
				chk_board( i );   /* initialize each board */
		}
		else    /* default mode, compatible with older lsinit function */
		{
			switch( addr )
			{
				case 1:
					break;
				case 2:
					address_array[0] += ALT_OFFSET;
					break;
				case 3:
					address_array[0] = ALT_ADDR_2;
					break;
				case 4:
					address_array[0] = ALT_ADDR_2 + ALT_OFFSET;
					break;
				default:
					printf( "\nNot a valid PG-1281 address\n" );
					exit( -1 );
			}
			chk_board( 0 );
		}
	}
	else								 /* otherwise send output to file */
		pgcfile = fhandle;
}


/*------------------------------------------------------------------------*/

unsigned long sel_board( short board_num )

/*  Initializes the global variables ioseg (the base address of the selected
    board), and globcnt (the fifo_count of the selected board).
*/

{

	 if( board_num && (board_num >= num_boards) ) 
	 {
		 printf( "\nError: Board select number '%d' is not valid.\n", board_num );
		 exit( -1 );
	 }

	 ioseg = ( struct pg_com far * ) address_array[ board_num ];

	 globcnt = fifo_count[ board_num ];

}


