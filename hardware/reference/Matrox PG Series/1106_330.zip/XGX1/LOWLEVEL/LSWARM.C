/*/  Function name:  lswarm
*
*    Synopsis:  Execute a warm reset of the board.
*
*    Author:   Jean Dupre
*    Date:     Dec 15, 1987
*
*    Modification history:	Andre Allore  March 21 1989
*									Added file or board device check.
*    Calls:  None
*
*    Uses:  Global variable "ioseg" and "device".
*
*    Return value:  None
*/

#include  "def.h"
#include  "iolib.h"


/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;


/* Reference to the address structure of the board */

IMPORT  struct pg_com far  *ioseg;


void lswarm()

    {
	 if (device)
		 {	
	    ioseg->hstctrl = 0x000A;          /* input interrupt with msgin = 2 */
   	                                   /*  == warm reset */

	    while(ioseg->hstctrl != 0x0022)   /* wait for msgout = msgin */
   	     ;

    	 ioseg->hstctrl = 0x0007;          /* send reset go ahead value to msgin	*/

	    while(ioseg->hstctrl != 0x0007)   /* wait for msgout = 0 */
       	  ;
		 }
    }


