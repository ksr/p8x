/*/  Function name:  iogetf
*
*    Synopsis:  Get a float from the board FIFO.
*
*    Author:   Andre Allore
*    Date:     March 21, 1989
*
*    Modification history:
*
*    Calls:  rdfifocnt: get read FIFO count.
*
*    Uses:  Global variable "ioseg" and "device".
*				FIXPT data type.
*
*    Return value:  float 
*/

#include "def.h"
#include "iolib.h"


/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;


/* Reference to the address structure of the board */

IMPORT  struct pg_com far  *ioseg;


/*	Reference to read FIFO count function */

IMPORT  short rdfifocnt();


FIXPT iogetf()

    {
	 short  count;
    long  val;

	 if (device)
	    {		
		 count = rdfifocnt();
		 while (count < 2)
		 		count = rdfifocnt();
	
	    val = (unsigned long) (unsigned short) ioseg->fifo; /* get fractional part */ 
   	 val += (long) ioseg->fifo << 16;						  /* get integer part */
		 }
	 else
		 {
       printf("iogetf:  readback invalid from a file\n");
       exit(-1);
		 }	

    return((float)(val) / 65536.0);
    }
