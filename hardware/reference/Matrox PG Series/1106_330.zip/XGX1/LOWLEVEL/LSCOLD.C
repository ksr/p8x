/*/  Function name:  lscold
*
*    Synopsis:  Execute a cold reset of the board.
*
*    Author:   Jean Dupre
*    Date:     Dec 15, 1987
*
*    Modification history:	Andre Allore  March 21 1989
*									Added file or board device check.
*
*    Calls:  None
*
*    Uses:  Global variable "ioseg" and "device".
*
*    Return value:  None
*/


#include  "def.h"
#include  "iolib.h"


/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;


/* Reference to the address structure of the board */

IMPORT  struct pg_com far  *ioseg;


void lscold()

    {

	 if (device)
		 {			
	    ioseg->hstctrl = 0x0009;          /* input interrupt with msgin = 1 */
                                      	  /*  == cold reset */

   	 while(ioseg->hstctrl != 0x0011)   /* wait for msgout = msgin */
       	  ;

		 ioseg->hstctrl = 0x0007;          /* send reset go ahead value to msgin */

	    while(ioseg->hstctrl != 0x0007)   /* wait for msgout = 0 */
   	     ;
		 }
    }


