/*/  Function name:  iogeterror
*
*    Synopsis:  Get a word from the error report register.
*
*    Author:   Jean Dupre
*    Date:     Dec 15, 1987
*
*    Modification history:	Andre Allore  March 21 1989
*									Added file or board device check.
*
*    Calls:  Lib Shell "lslibsync" command.
*
*    Uses:  Global variable "ioseg" and "device".
*
*    Return value:  word 
*/


#include  "def.h"
#include  "iolib.h"

/* Specifies whether pgcfile points to the PG/SM-1281 or a regular file */

IMPORT  short  device;

/* Reference to the address structure of the board */

IMPORT  struct pg_com far  *ioseg;


short iogeterror()

    {
    short err_type = 0;

	 if (device)
			{
			lslibsync();                       /* Make sure that previous commands */
		                                      /* are completed */

			ioseg->hstaddr = 0x00180020L;      /* set up address of status register */

			if (ioseg->hstdata & 0x0200)       /* test if error status bit = 1 */
				{
				err_type = (short)(ioseg->err_reg);
				ioseg->hstclr_int = 0xBF;      /* clear error status bit */
				}
			}
	 else
        {
        printf("iogeterror:  readback invalid from a file\n");
        exit(-1);
        } 
 
    return(err_type);
    }


