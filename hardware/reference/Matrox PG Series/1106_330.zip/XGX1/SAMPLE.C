/*/  sample.c
*
*    Sample program for the PG-1281 C binding library.
*/


void main()

    {

    lsinit(0, 1);

    krhwsclr(24);

    scolsw(15);
    krhwsfcol(0);
    krhwstdef(1);

    lssfont(-1);
    sctxssf(2.0, 3.0);

    scolrrect(310, 350, 940, 650, 20, 20);
    sctxbstring(405, 450, "Matrox PG-1281");

    }

